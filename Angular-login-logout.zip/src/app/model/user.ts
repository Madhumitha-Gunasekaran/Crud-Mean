export class User {
    _id:String
    Name:String
    Age:String
    office:String
    password:String
}
